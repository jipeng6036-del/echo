// SPDX-License-Identifier: MIT
// SPDX-FileCopyrightText: © 2015 LabStack LLC and Echo contributors

package echo

import (
	"bytes"
	"errors"
	"net/http"
	"net/url"
	"slices"
	"strings"
)

// Router is interface for routing request contexts to registered routes.
//
// Contract between Echo/Context instance and the router:
//   - all routes should be added through methods on echo.Echo instance.
//     Reason: Echo instance uses RouteInfo.Parameters length to allocate slice for paths parameters (see `Echo.contextPathParamAllocSize`),
//     so Contexts are created with enough capacity.
//   - Router.Route must handle a Context whose PathValues capacity is smaller than the maximum path parameter count
//     of its routes (for example, when a route was added after the Context was created, or not through echo.Echo).
//   - Router must populate Context during Router.Route call with:
//   - Context.InitializeRoute (IMPORTANT! to reduce allocations use same slice that c.PathValues() returns)
//   - Optionally can set additional information to Context with Context.Set
type Router interface {
	// Add registers Routable with the Router and returns registered RouteInfo.
	//
	// Router may change Route.Path value in returned RouteInfo.Path.
	// Router generates RouteInfo.Parameters values from Route.Path.
	// Router generates RouteInfo.Name value if it is not provided.
	Add(routable Route) (RouteInfo, error)

	// Remove removes route from the Router.
	//
	// Router may choose not to implement this method.
	Remove(method string, path string) error

	// Routes returns information about all registered routes
	Routes() Routes

	// Route searches Router for matching route and applies it to the given context. In case when no matching method
	// was not found (405) or no matching route exists for path (404), router will return its implementation of 405/404
	// handler function.
	//
	// Router must populate Context during Router.Route call with:
	// - Context.InitializeRoute() (IMPORTANT! to reduce allocations use same slice that c.PathValues() returns)
	// - optionally can set additional information to Context with Context.Set()
	Route(c *Context) HandlerFunc
}

const (
	// NotFoundRouteName is name of RouteInfo returned when router did not find matching route (404: not found).
	NotFoundRouteName = "echo_route_not_found_name"
	// MethodNotAllowedRouteName is name of RouteInfo returned when router did not find matching method for route  (405: method not allowed).
	MethodNotAllowedRouteName = "echo_route_method_not_allowed_name"
)

// Routes is collection of RouteInfo instances with various helper methods.
type Routes []RouteInfo

// DefaultRouter is the registry of all registered routes for an `Echo` instance for
// request matching and URL path parameter parsing.
// Note: DefaultRouter is not coroutine-safe. Do not Add/Remove routes after HTTP server has been started with Echo.
type DefaultRouter struct {
	tree                    *node
	notFoundHandler         HandlerFunc
	methodNotAllowedHandler HandlerFunc
	optionsMethodHandler    HandlerFunc
	routes                  Routes
	// maxPathParamsLength tracks highest count of PathValues for all routes.
	maxPathParamsLength int

	allowOverwritingRoute    bool
	unescapePathParamValues  bool
	useEscapedPathForRouting bool
	autoHandleHEAD           bool
}

// RouterConfig is configuration options for (default) router
type RouterConfig struct {
	// NotFoundHandler is a handler that is executed when no route matches the request.
	NotFoundHandler HandlerFunc

	// MethodNotAllowedHandler is a handler that is executed when no route with exact METHOD matches the request but
	// there is a route with same path but different method.
	MethodNotAllowedHandler HandlerFunc

	// OptionsMethodHandler is a handler that is executed when an OPTIONS request is made.
	OptionsMethodHandler HandlerFunc

	// AllowOverwritingRoute allows overwriting existing routes. If false, then adding a route with the same method
	// and path will return an error.
	AllowOverwritingRoute bool

	// UnescapePathParamValues forces router to unescape path parameter values before setting them in context.
	UnescapePathParamValues bool

	// UseEscapedPathForMatching forces router to use an escaped path (req.URL.RawPath instead of req.URL.Path) for matching.
	// Difference between URL.RawPath and URL.Path is:
	//  * URL.Path is where request path is stored. Value is stored in decoded form: /%47%6f%2f becomes /Go/.
	//  * URL.RawPath is an optional field which only gets set if the default encoding is different from Path.
	UseEscapedPathForMatching bool

	// AutoHandleHEAD enables automatic handling of HTTP HEAD requests by
	// falling back to the corresponding GET route.
	//
	// When enabled, a HEAD request will match the same handler as GET for
	// the route, but the response body is suppressed in accordance with
	// HTTP semantics. Headers (e.g., Content-Length, Content-Type) are
	// preserved as if a GET request was made.
	//
	// Security considerations: the GET handler is fully executed for every
	// HEAD request, including all side effects:
	//   - State-mutating operations (DB writes, audit logs, counters) run.
	//   - Rate-limiting middleware consumes quota, enabling low-cost exhaustion.
	//   - Expensive computations run with no response body returned to the
	//     caller, making HEAD cheaper to abuse for DoS than GET.
	//   - All GET routes become enumerable via HEAD probing (200 = route
	//     exists, 405 = route absent).
	//
	// If route confidentiality/state-mutation is a concern, leave AutoHandleHEAD disabled
	// and register explicit HEAD handlers only for routes that are safe to
	// expose (e.g. e.HEAD("/public", handler)).
	// You can leverage Echo.OnAddRoute callback to add HEAD routes explicitly from a single place.
	//
	// Disabled by default.
	AutoHandleHEAD bool
}

// NewRouter returns a new Router instance.
func NewRouter(config RouterConfig) *DefaultRouter {
	r := &DefaultRouter{
		tree: &node{
			methods:   new(routeMethods),
			isLeaf:    true,
			isHandler: false,
		},
		routes: make(Routes, 0),

		allowOverwritingRoute:    config.AllowOverwritingRoute,
		unescapePathParamValues:  config.UnescapePathParamValues,
		useEscapedPathForRouting: config.UseEscapedPathForMatching,

		notFoundHandler:         notFoundHandler,
		methodNotAllowedHandler: methodNotAllowedHandler,
		optionsMethodHandler:    optionsMethodHandler,
		autoHandleHEAD:          config.AutoHandleHEAD,
	}
	if config.NotFoundHandler != nil {
		r.notFoundHandler = config.NotFoundHandler
	}
	if config.MethodNotAllowedHandler != nil {
		r.methodNotAllowedHandler = config.MethodNotAllowedHandler
	}
	if config.OptionsMethodHandler != nil {
		r.optionsMethodHandler = config.OptionsMethodHandler
	}
	return r
}

type children []*node

type node struct {
	parent         *node
	methods        *routeMethods
	paramChild     *node
	anyChild       *node
	prefix         string
	originalPath   string
	staticChildren children
	// scLabels holds the first byte (label) of each staticChildren entry in the
	// same order. Scanning this contiguous byte slice during routing is more
	// cache-friendly than dereferencing each *node to read its label.
	scLabels      []byte
	paramsCount   int
	kind          kind
	label         byte
	isLeaf        bool
	isHandler     bool
	hasColonChild bool
}

type kind uint8

const (
	staticKind kind = iota
	paramKind
	anyKind

	paramLabel = byte(':')
	anyLabel   = byte('*')
)

type routeMethod struct {
	*RouteInfo
	handler            HandlerFunc
	wrappedHeadHandler HandlerFunc // non-nil only for GET routes when autoHandleHEAD=true
	orgRouteInfo       RouteInfo
}

type routeMethods struct {
	connect  *routeMethod
	delete   *routeMethod
	get      *routeMethod
	head     *routeMethod
	options  *routeMethod
	patch    *routeMethod
	post     *routeMethod
	propfind *routeMethod
	put      *routeMethod
	trace    *routeMethod
	report   *routeMethod
	query    *routeMethod
	any      *routeMethod
	anyOther map[string]*routeMethod

	// notFoundHandler is handler registered with RouteNotFound method and is executed for 404 cases
	notFoundHandler *routeMethod

	// allowHeader contains comma-separated list of Methods registered to this node path.
	// it is optimization for http.StatusMethodNotAllowed (405) handling.
	allowHeader string
}

func (m *routeMethods) set(method string, r *routeMethod) {
	switch method {
	case http.MethodConnect:
		m.connect = r
	case http.MethodDelete:
		m.delete = r
	case http.MethodGet:
		m.get = r
	case http.MethodHead:
		m.head = r
	case http.MethodOptions:
		m.options = r
	case http.MethodPatch:
		m.patch = r
	case http.MethodPost:
		m.post = r
	case PROPFIND:
		m.propfind = r
	case http.MethodPut:
		m.put = r
	case http.MethodTrace:
		m.trace = r
	case REPORT:
		m.report = r
	case QUERY:
		m.query = r
	case RouteAny:
		m.any = r
	case RouteNotFound:
		m.notFoundHandler = r
		return // RouteNotFound/404 is not considered as a handler so no further logic needs to be executed
	default:
		if m.anyOther == nil {
			m.anyOther = make(map[string]*routeMethod)
		}
		if r == nil || r.handler == nil { // Router.Remove passes nil
			delete(m.anyOther, method)
		} else {
			m.anyOther[method] = r
		}
	}
	m.updateAllowHeader()
}

func (m *routeMethods) find(method string, fallbackToAny bool, autoHandleHEAD bool) *routeMethod {
	var r *routeMethod
	switch method {
	case http.MethodConnect:
		r = m.connect
	case http.MethodDelete:
		r = m.delete
	case http.MethodGet:
		r = m.get
	case http.MethodHead:
		r = m.head
		if autoHandleHEAD && r == nil {
			r = m.get
		}
	case http.MethodOptions:
		r = m.options
	case http.MethodPatch:
		r = m.patch
	case http.MethodPost:
		r = m.post
	case PROPFIND:
		r = m.propfind
	case http.MethodPut:
		r = m.put
	case http.MethodTrace:
		r = m.trace
	case REPORT:
		r = m.report
	case QUERY:
		r = m.query
	case RouteAny:
		r = m.any
	case RouteNotFound:
		r = m.notFoundHandler
	default:
		r = m.anyOther[method]
	}
	if r != nil || !fallbackToAny {
		return r
	}
	return m.any
}

func (m *routeMethods) updateAllowHeader() {
	buf := new(bytes.Buffer)
	buf.WriteString(http.MethodOptions)
	hasAnyMethod := m.any != nil

	if hasAnyMethod || m.connect != nil {
		buf.WriteString(", ")
		buf.WriteString(http.MethodConnect)
	}
	if hasAnyMethod || m.delete != nil {
		buf.WriteString(", ")
		buf.WriteString(http.MethodDelete)
	}
	if hasAnyMethod || m.get != nil {
		buf.WriteString(", ")
		buf.WriteString(http.MethodGet)
	}
	if hasAnyMethod || m.head != nil {
		buf.WriteString(", ")
		buf.WriteString(http.MethodHead)
	}
	if hasAnyMethod || m.patch != nil {
		buf.WriteString(", ")
		buf.WriteString(http.MethodPatch)
	}
	if hasAnyMethod || m.post != nil {
		buf.WriteString(", ")
		buf.WriteString(http.MethodPost)
	}
	if hasAnyMethod || m.propfind != nil {
		buf.WriteString(", PROPFIND")
	}
	if hasAnyMethod || m.put != nil {
		buf.WriteString(", ")
		buf.WriteString(http.MethodPut)
	}
	if hasAnyMethod || m.trace != nil {
		buf.WriteString(", ")
		buf.WriteString(http.MethodTrace)
	}
	if hasAnyMethod || m.report != nil {
		buf.WriteString(", REPORT")
	}
	if hasAnyMethod || m.query != nil {
		buf.WriteString(", QUERY")
	}
	for method := range m.anyOther { // for simplicity, we use map and therefore order is not deterministic here
		buf.WriteString(", ")
		buf.WriteString(method)
	}
	m.allowHeader = buf.String()
}

func (m *routeMethods) isHandler() bool {
	return m.get != nil ||
		m.post != nil ||
		m.options != nil ||
		m.put != nil ||
		m.delete != nil ||
		m.connect != nil ||
		m.head != nil ||
		m.patch != nil ||
		m.propfind != nil ||
		m.trace != nil ||
		m.report != nil ||
		m.query != nil ||
		m.any != nil ||
		len(m.anyOther) != 0
	// RouteNotFound/404 is not considered as a handler
}

// Routes returns all registered routes
func (r *DefaultRouter) Routes() Routes {
	return r.routes
}

// Remove unregisters registered route
func (r *DefaultRouter) Remove(method string, path string) error {
	currentNode := r.tree
	if currentNode == nil || (currentNode.isLeaf && !currentNode.isHandler) {
		return errors.New("router has no routes to remove")
	}

	path = normalizePathSlash(path)
	treePath, paramMarkers := routeTreePath(parseRoutePath(path))

	var nodeToRemove *node
	search := treePath
	searchOffset := 0
	for {
		if !strings.HasPrefix(search, currentNode.prefix) {
			break
		}
		search = search[len(currentNode.prefix):]
		searchOffset += len(currentNode.prefix)

		if search == "" {
			if currentNode.isHandler {
				nodeToRemove = currentNode
			}
			break
		}

		currentNode = currentNode.findChildWithLabel(search[0], slices.Contains(paramMarkers, searchOffset))
		if currentNode == nil {
			break
		}
	}

	if nodeToRemove == nil {
		return errors.New("could not find route to remove by given path")
	}

	if !nodeToRemove.isHandler {
		return errors.New("could not find route to remove by given path")
	}

	// routes with different param names can share a node, so the path must be the one registered for this method
	mh := nodeToRemove.methods.find(method, false, false)
	if mh == nil || mh.Path != path {
		return errors.New("could not find route to remove by given path and method")
	}

	rIndex := -1
	for i, rr := range r.routes {
		if rr.Method == method && rr.Path == mh.orgRouteInfo.Path {
			rIndex = i
			break
		}
	}
	if rIndex < 0 {
		return errors.New("could not find route to remove by given path and method")
	}
	nodeToRemove.setHandler(method, nil)
	r.routes = append(r.routes[:rIndex], r.routes[rIndex+1:]...)

	if !nodeToRemove.isHandler && nodeToRemove.isLeaf {
		// TODO: if !nodeToRemove.isLeaf and has at least 2 children merge paths for remaining nodes?
		current := nodeToRemove
		for {
			parent := current.parent
			if parent == nil {
				break
			}
			switch current.kind {
			case staticKind:
				var index int
				for i, c := range parent.staticChildren {
					if c == current {
						index = i
						break
					}
				}
				parent.staticChildren = append(parent.staticChildren[:index], parent.staticChildren[index+1:]...)
				parent.scLabels = append(parent.scLabels[:index], parent.scLabels[index+1:]...)
				if current.label == ':' {
					parent.hasColonChild = false
				}
			case paramKind:
				parent.paramChild = nil
			case anyKind:
				parent.anyChild = nil
			}

			parent.refreshLeaf()
			if !parent.isLeaf || parent.isHandler {
				break
			}
			current = parent
		}
	}

	return nil
}

// AddRouteError is error returned by Router.Add containing information what actual route adding failed. Useful for
// mass adding (i.e. Match() routes)
type AddRouteError struct {
	Err    error
	Method string
	Path   string
}

func (e *AddRouteError) Error() string { return e.Method + " " + e.Path + ": " + e.Err.Error() }

func (e *AddRouteError) Unwrap() error { return e.Err }

func newAddRouteError(route Route, err error) *AddRouteError {
	return &AddRouteError{
		Method: route.Method,
		Path:   route.Path,
		Err:    err,
	}
}

// Add registers a new route for method and path with matching handler.
func (r *DefaultRouter) Add(route Route) (RouteInfo, error) {
	allowOverwritingRoute := r.allowOverwritingRoute || route.allowOverwrite

	if route.Handler == nil {
		switch route.Method {
		case RouteNotFound:
			route.Handler = r.notFoundHandler
		case http.MethodOptions:
			route.Handler = r.optionsMethodHandler
		default:
			return RouteInfo{}, newAddRouteError(route, errors.New("adding route without handler function"))
		}
	}

	method := route.Method
	path := normalizePathSlash(route.Path)

	h := applyMiddleware(route.Handler, route.Middlewares...)
	if !allowOverwritingRoute {
		for _, rr := range r.routes {
			if route.Method == rr.Method && route.Path == rr.Path {
				return RouteInfo{}, newAddRouteError(route, errors.New("adding duplicate route (same method+path) is not allowed"))
			}
		}
	}
	var headH HandlerFunc
	if r.autoHandleHEAD && method == http.MethodGet {
		headH = wrapHeadHandler(h)
	}

	parts := parseRoutePath(path)
	var paramNames []string
	for _, part := range parts {
		if part.kind == paramKind {
			paramNames = append(paramNames, part.value)
		} else if part.kind == anyKind {
			paramNames = append(paramNames, "*")
			break
		}
	}
	ri := route.ToRouteInfo(paramNames)
	rm := routeMethod{
		RouteInfo:          &RouteInfo{Method: method, Path: path, Parameters: paramNames, Name: route.Name},
		handler:            h,
		orgRouteInfo:       ri,
		wrappedHeadHandler: headH,
	}
	partial := routeMethod{RouteInfo: &RouteInfo{Method: method}}
	treePath, paramMarkers := routeTreePath(parts)
	pathEnd := 0
addParts:
	for i, part := range parts {
		switch part.kind {
		case staticKind:
			pathEnd += len(part.value)
			if i == len(parts)-1 {
				r.insert(staticKind, treePath[:pathEnd], method, rm, paramMarkers)
			}
		case paramKind:
			r.insert(staticKind, treePath[:pathEnd], method, partial, paramMarkers)
			pathEnd++
			if i == len(parts)-1 {
				r.insert(paramKind, treePath[:pathEnd], method, rm, paramMarkers)
			} else {
				r.insert(paramKind, treePath[:pathEnd], method, partial, paramMarkers)
			}
		case anyKind:
			r.insert(staticKind, treePath[:pathEnd], method, partial, paramMarkers)
			pathEnd++
			r.insert(anyKind, treePath[:pathEnd], method, rm, paramMarkers)
			break addParts
		}
	}

	r.storeRouteInfo(ri)

	return ri, nil
}

func normalizePathSlash(path string) string {
	if path == "" {
		path = "/"
	} else if path[0] != '/' {
		path = "/" + path
	}
	return path
}

func (r *DefaultRouter) storeRouteInfo(ri RouteInfo) {
	for i, rr := range r.routes {
		if ri.Method == rr.Method && ri.Path == rr.Path {
			r.routes[i] = ri
			return
		}
	}
	r.routes = append(r.routes, ri)
}

func (r *DefaultRouter) insert(t kind, path string, method string, ri routeMethod, paramMarkers []int) {
	if len(ri.Parameters) > r.maxPathParamsLength {
		r.maxPathParamsLength = len(ri.Parameters)
	}
	currentNode := r.tree // Current node as root
	search := path
	searchOffset := 0

	for {
		searchLen := len(search)
		prefixLen := len(currentNode.prefix)
		lcpLen := 0

		// LCP - Longest Common Prefix (https://en.wikipedia.org/wiki/LCP_array)
		maxL := min(searchLen, prefixLen)
		for ; lcpLen < maxL && search[lcpLen] == currentNode.prefix[lcpLen]; lcpLen++ {
		}

		if lcpLen == 0 {
			// At root node
			currentNode.label = search[0]
			currentNode.prefix = search
			if ri.handler != nil {
				currentNode.kind = t
				currentNode.setHandler(method, &ri)
				currentNode.paramsCount = len(ri.Parameters)
				currentNode.originalPath = ri.Path
			}
			currentNode.refreshLeaf()
		} else if lcpLen < prefixLen {
			// Split node into two before we insert new node.
			// This happens when we are inserting path that is submatch of any existing inserted paths.
			// For example, we have node `/test` and now are about to insert `/te/*`. In that case
			// 1. overlapping part is `/te` that is used as parent node
			// 2. `st` is part from existing node that is not matching - it gets its own node (child to `/te`)
			// 3. `/*` is the new part we are about to insert (child to `/te`)
			n := newNode(
				currentNode.kind,
				currentNode.prefix[lcpLen:],
				currentNode,
				currentNode.staticChildren,
				currentNode.methods,
				currentNode.paramsCount,
				currentNode.originalPath,
				currentNode.paramChild,
				currentNode.anyChild,
			)
			// Update parent path for all children to new node
			for _, child := range currentNode.staticChildren {
				child.parent = n
			}
			if currentNode.paramChild != nil {
				currentNode.paramChild.parent = n
			}
			if currentNode.anyChild != nil {
				currentNode.anyChild.parent = n
			}

			// Reset parent node
			currentNode.kind = staticKind
			currentNode.label = currentNode.prefix[0]
			currentNode.prefix = currentNode.prefix[:lcpLen]
			currentNode.staticChildren = nil
			currentNode.scLabels = nil
			currentNode.methods = new(routeMethods)
			currentNode.originalPath = ""
			currentNode.paramsCount = 0
			currentNode.paramChild = nil
			currentNode.anyChild = nil
			currentNode.isLeaf = false
			currentNode.isHandler = false

			// Only Static children could reach here
			currentNode.addStaticChild(n)

			if lcpLen == searchLen {
				// At parent node
				currentNode.kind = t
				if ri.handler != nil {
					currentNode.setHandler(method, &ri)
					currentNode.paramsCount = len(ri.Parameters)
					currentNode.originalPath = ri.Path
				}
			} else {
				// Create child node
				n = newNode(t, search[lcpLen:], currentNode, nil, new(routeMethods), 0, ri.Path, nil, nil)
				if ri.handler != nil {
					n.setHandler(method, &ri)
					n.paramsCount = len(ri.Parameters)
				}
				// Only Static children could reach here
				currentNode.addStaticChild(n)
			}
			currentNode.refreshLeaf()
		} else if lcpLen < searchLen {
			searchOffset += lcpLen
			search = search[lcpLen:]
			c := currentNode.findChildWithLabel(search[0], slices.Contains(paramMarkers, searchOffset))
			if c != nil {
				// Go deeper
				currentNode = c
				continue
			}
			// Create child node
			n := newNode(t, search, currentNode, nil, new(routeMethods), 0, ri.Path, nil, nil)
			if ri.handler != nil {
				n.setHandler(method, &ri)
				n.paramsCount = len(ri.Parameters)
			}
			switch t {
			case staticKind:
				currentNode.addStaticChild(n)
			case paramKind:
				currentNode.paramChild = n
			case anyKind:
				currentNode.anyChild = n
			}
			currentNode.refreshLeaf()
		} else {
			// Node already exists
			if ri.handler != nil {
				currentNode.setHandler(method, &ri)
				currentNode.paramsCount = len(ri.Parameters)
				currentNode.originalPath = ri.Path
			}
		}
		return
	}
}

func newNode(
	t kind,
	pre string,
	p *node,
	sc children,
	mh *routeMethods,
	paramsCount int,
	ppath string,
	paramChildren,
	anyChildren *node,
) *node {
	var scLabels []byte
	if len(sc) > 0 {
		scLabels = make([]byte, len(sc))
		for i, c := range sc {
			scLabels[i] = c.label
		}
	}
	return &node{
		kind:           t,
		label:          pre[0],
		prefix:         pre,
		parent:         p,
		staticChildren: sc,
		scLabels:       scLabels,
		originalPath:   ppath,
		paramsCount:    paramsCount,
		methods:        mh,
		paramChild:     paramChildren,
		anyChild:       anyChildren,
		// len() (not == nil) so an empty-but-non-nil sc — e.g. a slice from a
		// prior Remove that was spliced down to length 0 — is still treated as
		// no children, matching refreshLeaf.
		isLeaf:    len(sc) == 0 && paramChildren == nil && anyChildren == nil,
		isHandler: mh.isHandler(),
	}
}

// refreshLeaf recomputes whether the node is a leaf (has no children of any
// kind). len() is used for staticChildren so it stays correct whether the slice
// is nil or an emptied-but-non-nil slice left behind after a removal.
func (n *node) refreshLeaf() {
	n.isLeaf = len(n.staticChildren) == 0 && n.paramChild == nil && n.anyChild == nil
}

func (n *node) addStaticChild(c *node) {
	n.staticChildren = append(n.staticChildren, c)
	n.scLabels = append(n.scLabels, c.label)
	// param nodes are never split (their prefix is a single byte), so this is where their inline verb child is set
	if n.kind == paramKind && c.label == ':' {
		n.hasColonChild = true
	}
}

// hasPendingInlineVerbSplit reports whether a param node from n up to the root has a value in pathValues that ended at
// an inline verb split and so can still be retried. searchIndex and paramIndex are the routing state at n. It does
// not change that state, so a request that ends here keeps its param values.
func hasPendingInlineVerbSplit(n *node, path string, searchIndex, paramIndex int, pathValues PathValues) bool {
	for ; n != nil; n = n.parent {
		if n.hasColonChild && searchIndex < len(path) && path[searchIndex] == ':' {
			return true
		}
		if n.kind == staticKind {
			searchIndex -= len(n.prefix)
		} else {
			paramIndex--
			searchIndex -= len(pathValues[paramIndex].Value)
		}
	}
	return false
}

// inlineVerbSplit returns where a param value in search ends: at the first literal colon at or after from where this
// node's inline verb child could match, otherwise at the end of the path segment (or of the path when that child is the
// node's only child). A split value is never empty. The scan stops at the next slash, so trying every split of a
// segment in turn is linear in its length.
//
// A split is only chosen when the whole prefix of the inline verb child matches. Routing therefore never backtracks
// into the param node from a prefix mismatch of that child, and the split only needs to be retried when backtracking
// from within the child's subtree.
func (n *node) inlineVerbSplit(search string, from int) int {
	verbs := n.findStaticChild(':')
	for i := from; i < len(search); i++ {
		switch search[i] {
		case '/':
			if len(n.staticChildren) == 1 {
				// the inline verb child is the only child (a param node never has a param or any child): without a
				// split the param takes the rest of the path, as a leaf param does
				return len(search)
			}
			return i
		case ':':
			if i > 0 && verbs != nil && strings.HasPrefix(search[i:], verbs.prefix) {
				return i
			}
		}
	}
	return len(search)
}

func (n *node) findStaticChild(l byte) *node {
	for i, cl := range n.scLabels {
		if cl == l {
			return n.staticChildren[i]
		}
	}
	return nil
}

func (n *node) findChildWithLabel(l byte, isParamMarker bool) *node {
	if isParamMarker {
		return n.paramChild
	}
	if c := n.findStaticChild(l); c != nil {
		return c
	}
	if l == anyLabel {
		return n.anyChild
	}
	return nil
}

func (n *node) setHandler(method string, r *routeMethod) {
	n.methods.set(method, r)
	n.isHandler = n.methods.isHandler()
}

// Note: notFoundRouteInfo exists to avoid allocations when setting 404 RouteInfo to Context
var notFoundRouteInfo = &RouteInfo{
	Method:     "",
	Path:       "",
	Parameters: nil,
	Name:       NotFoundRouteName,
}

// Note: methodNotAllowedRouteInfo exists to avoid allocations when setting 405 RouteInfo to Context
var methodNotAllowedRouteInfo = &RouteInfo{
	Method:     "",
	Path:       "",
	Parameters: nil,
	Name:       MethodNotAllowedRouteName,
}

// notFoundHandler is handler for 404 cases
// Handle returned ErrNotFound errors in Echo.HTTPErrorHandler
var notFoundHandler = func(c *Context) error {
	return ErrNotFound
}

// methodNotAllowedHandler is handler for case when route for path+method match was not found (http code 405)
// Handle returned ErrMethodNotAllowed errors in Echo.HTTPErrorHandler
var methodNotAllowedHandler = func(c *Context) error {
	// See RFC 7231 section 7.4.1: An origin server MUST generate an Allow field in a 405 (Method Not Allowed)
	// response and MAY do so in any other response. For disabled resources an empty Allow header may be returned
	routerAllowMethods, ok := c.Get(ContextKeyHeaderAllow).(string)
	if ok && routerAllowMethods != "" {
		c.Response().Header().Set(HeaderAllow, routerAllowMethods)
	}
	return ErrMethodNotAllowed
}

// optionsMethodHandler is default handler for OPTIONS method.
// Use `middleware.CORS` if you need support for preflighted requests in CORS
// See https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/OPTIONS
var optionsMethodHandler = func(c *Context) error {
	// See RFC 7231 section 7.4.1: An origin server MUST generate an Allow field in a 405 (Method Not Allowed)
	// response and MAY do so in any other response. For disabled resources an empty Allow header may be returned
	routerAllowMethods, ok := c.Get(ContextKeyHeaderAllow).(string)
	if ok && routerAllowMethods != "" {
		c.Response().Header().Set(HeaderAllow, routerAllowMethods)
	}
	return c.NoContent(http.StatusNoContent)
}

// Route looks up a handler registered for method and path. It also parses URL for path parameters and loads them
// into context.
//
// For performance:
//
// - Get context from `Echo#AcquireContext()`
// - Reset it `Context#Reset()`
// - Return it `Echo#ReleaseContext()`.
func (r *DefaultRouter) Route(c *Context) HandlerFunc {
	pathValues := c.PathValues()
	if cap(pathValues) < r.maxPathParamsLength {
		// The Context has less capacity than this router's routes need, for example because it was created before a
		// route with more params was added. Grow its PathValues at full length so values can be set by index below. The
		// Context keeps the new slice, so later requests do not grow it again unless a route with more params is added.
		*c.pathValues = make(PathValues, r.maxPathParamsLength)
		pathValues = *c.pathValues
	} else {
		pathValues = pathValues[0:cap(pathValues)] // resize slice to maximum capacity so we can index set values
	}

	req := c.Request()
	path := req.URL.Path
	if !r.useEscapedPathForRouting && req.URL.RawPath != "" {
		// Difference between URL.RawPath and URL.Path is:
		//  * URL.Path is where request path is stored. Value is stored in decoded form: /%47%6f%2f becomes /Go/.
		//  * URL.RawPath is an optional field which only gets set if the default encoding is different from Path.
		path = req.URL.RawPath
	}
	var (
		currentNode           = r.tree // root as current node
		previousBestMatchNode *node
		matchedRouteMethod    *routeMethod
		// search stores the remaining path to check for match. By each iteration we move from start of path to end of the path
		// and search value gets shorter and shorter.
		search      = path
		searchIndex = 0
		paramIndex  int // Param counter
	)

	// Backtracking is needed when a dead end (leaf node) is reached in the router tree.
	// To backtrack the current node will be changed to the parent node and the next kind for the
	// router logic will be returned based on fromKind or kind of the dead end node (static > param > any).
	// For example if there is no static node match we should check parent next sibling by kind (param).
	// Backtracking itself does not check if there is a next sibling, this is done by the router logic.
	backtrackToNextNodeKind := func(fromKind kind) (nextNodeKind kind, valid bool) {
		previous := currentNode
		currentNode = previous.parent
		valid = currentNode != nil

		// Next node type by priority
		if previous.kind == anyKind {
			nextNodeKind = staticKind
		} else {
			nextNodeKind = previous.kind + 1
		}

		if fromKind == staticKind {
			// when backtracking is done from static kind block we did not change search so nothing to restore
			return
		}

		// restore search to value it was before we move to current node we are backtracking from.
		if previous.kind == staticKind {
			searchIndex -= len(previous.prefix)
		} else {
			paramIndex--
			// param/any node prefixes are a single marker byte, so restore searchIndex
			// from the value stored for that param instead
			searchIndex -= len(pathValues[paramIndex].Value)
			pathValues[paramIndex].Value = ""
		}
		search = path[searchIndex:]
		return
	}

	// Router tree is implemented by longest common prefix array (LCP array) https://en.wikipedia.org/wiki/LCP_array
	// Tree search is implemented as for loop where one loop iteration is divided into 3 separate blocks
	// Each of these blocks checks specific kind of node (static/param/any). Order of blocks reflex their priority in routing.
	// Search order/priority is: static > param > any.
	//
	// Note: backtracking in tree is implemented by replacing/switching currentNode to previous node
	// and hoping to (goto statement) next block by priority to check if it is the match.
	for {
		prefixLen := 0 // Prefix length
		lcpLen := 0    // LCP (longest common prefix) length

		if currentNode.kind == staticKind {
			searchLen := len(search)
			prefixLen = len(currentNode.prefix)

			// LCP - Longest Common Prefix (https://en.wikipedia.org/wiki/LCP_array)
			lMax := min(searchLen, prefixLen)
			for ; lcpLen < lMax && search[lcpLen] == currentNode.prefix[lcpLen]; lcpLen++ {
			}
		}

		if lcpLen != prefixLen {
			// No matching prefix, let's backtrack to the first possible alternative node of the decision path
			nk, ok := backtrackToNextNodeKind(staticKind)
			if !ok {
				break // No other possibilities on the decision path, handler will be whatever context is reset to.
			} else if nk == paramKind {
				goto Param
				// NOTE: this case (backtracking from static node to previous any node) can not happen by current any matching logic. Any node is end of search currently
				//} else if nk == anyKind {
				//	goto Any
			} else {
				// Not found (this should never be possible for static node we are looking currently)
				break
			}
		}

		// The full prefix has matched, remove the prefix from the remaining search
		search = search[lcpLen:]
		searchIndex = searchIndex + lcpLen

		// Finish routing if is no request path remaining to search
		if search == "" {
			// in case of node that is handler we have exact method type match or something for 405 to use
			if currentNode.isHandler {
				// check if current node has handler registered for http method we are looking for. we store currentNode as
				// best matching in case we do no find no more routes matching this path+method
				if previousBestMatchNode == nil {
					previousBestMatchNode = currentNode
				}
				if h := currentNode.methods.find(req.Method, true, r.autoHandleHEAD); h != nil {
					matchedRouteMethod = h
					break
				}
			} else if currentNode.methods.notFoundHandler != nil {
				matchedRouteMethod = currentNode.methods.notFoundHandler
				break
			}
		}

		// Static node
		if search != "" {
			if child := currentNode.findStaticChild(search[0]); child != nil {
				currentNode = child
				continue
			}
		}

	Param:
		// Param node
		if child := currentNode.paramChild; search != "" && child != nil {
			currentNode = child
			i := 0
			l := len(search)
			if currentNode.isLeaf {
				// when param node does not have any children (path param is last piece of route path) then param node should
				// act similarly to any node - consider all remaining search as match
				i = l
			} else if currentNode.hasColonChild {
				// an inline verb (`/:name\:verb`) can end the param value at a literal colon. Start with the first
				// possible split, the param node is retried with the next one before backtracking (see below).
				i = currentNode.inlineVerbSplit(search, 0)
			} else if i = strings.IndexByte(search, '/'); i < 0 {
				i = l
			}

			pathValues[paramIndex].Value = search[:i]
			paramIndex++
			search = search[i:]
			searchIndex = searchIndex + i
			continue
		}

	Any:
		// Any node
		if child := currentNode.anyChild; child != nil {
			// If any node is found, use remaining path for paramValues
			currentNode = child
			pathValues[currentNode.paramsCount-1].Value = search
			// update indexes/search in case we need to backtrack when no handler match is found
			paramIndex++
			searchIndex += len(search)
			search = ""

			if rMethod := currentNode.methods.find(req.Method, true, r.autoHandleHEAD); rMethod != nil {
				matchedRouteMethod = rMethod
				break
			}
			// we store currentNode as best matching in case we do not find more routes matching this path+method. Needed for 405
			if previousBestMatchNode == nil {
				previousBestMatchNode = currentNode
			}
			if currentNode.methods.notFoundHandler != nil {
				matchedRouteMethod = currentNode.methods.notFoundHandler
				break
			}
		}

		// Let's backtrack to the first possible alternative node of the decision path
		nk, ok := backtrackToNextNodeKind(anyKind)
	Backtracked:
		if !ok {
			break // No other possibilities on the decision path
		} else if nk == paramKind {
			if currentNode.hasColonChild && search != "" && search[0] == ':' {
				goto InlineVerbSplit
			}
			goto Param
		} else if nk == anyKind {
			goto Any
		} else if hasPendingInlineVerbSplit(currentNode, path, searchIndex, paramIndex, pathValues) {
			// A wildcard ends the search, except below a param value that ended at an inline verb split: keep
			// backtracking, so the other routes below that split and then the next split are still tried.
			nk, ok = backtrackToNextNodeKind(anyKind)
			goto Backtracked
		} else {
			// Not found
			break
		}

	InlineVerbSplit:
		// A param value that ended at an inline verb split is a decision point of the param node itself. When its
		// inline verb child fails, retry the node with the next split, and finally with the whole path segment,
		// before backtracking to its parent.
		pv := &pathValues[paramIndex-1]
		start := searchIndex - len(pv.Value)
		searchIndex = start + currentNode.inlineVerbSplit(path[start:], len(pv.Value)+1)
		pv.Value = path[start:searchIndex]
		search = path[searchIndex:]
		continue
	}

	if currentNode == nil && previousBestMatchNode == nil {
		pathValues = pathValues[0:0]

		c.InitializeRoute(notFoundRouteInfo, &pathValues)
		return r.notFoundHandler // nothing matched at all with given path
	}

	var rHandler HandlerFunc
	var rPath string
	var rInfo *RouteInfo
	if matchedRouteMethod != nil {
		rHandler = matchedRouteMethod.handler
		if req.Method == http.MethodHead && matchedRouteMethod.wrappedHeadHandler != nil {
			rHandler = matchedRouteMethod.wrappedHeadHandler
			// we are not touching rInfo.Method and let it be value from GET routeInfo
		}

		rPath = matchedRouteMethod.Path
		rInfo = matchedRouteMethod.RouteInfo
	} else {
		// use previous match as basis. although we have no matching handler we have path match.
		// so we can send http.StatusMethodNotAllowed (405) instead of http.StatusNotFound (404)
		currentNode = previousBestMatchNode

		rPath = currentNode.originalPath
		rInfo = notFoundRouteInfo
		if currentNode.methods.notFoundHandler != nil {
			matchedRouteMethod = currentNode.methods.notFoundHandler

			rInfo = matchedRouteMethod.RouteInfo
			rPath = matchedRouteMethod.Path
			rHandler = matchedRouteMethod.handler
		} else if currentNode.isHandler {
			rInfo = methodNotAllowedRouteInfo

			c.Set(ContextKeyHeaderAllow, currentNode.methods.allowHeader)
			rHandler = r.methodNotAllowedHandler
			if req.Method == http.MethodOptions {
				rHandler = r.optionsMethodHandler
			}
		}
	}

	pathValues = pathValues[0:currentNode.paramsCount]
	if matchedRouteMethod != nil {
		for i, name := range matchedRouteMethod.Parameters {
			pathValues[i].Name = name
		}
	}

	if r.unescapePathParamValues {
		// See issue #1531, #1258 - there are cases when path parameter need to be unescaped
		for i, p := range pathValues {
			tmpVal, err := url.PathUnescape(p.Value)
			if err == nil { // handle problems by ignoring them.
				pathValues[i].Value = tmpVal
			}
		}
	}

	c.InitializeRoute(rInfo, &pathValues)
	c.SetPath(rPath)          // after InitializeRoute so we would not accidentally change `notFoundRouteInfo` or `methodNotAllowedRouteInfo` Path
	c.request.Pattern = rPath // help standard library based middlewares. This is a deliberate choice not to call `request.SetPathValue` for params.
	return rHandler
}

// PathValues is collections of PathValue instances with various helper methods
type PathValues []PathValue

// PathValue is tuple pf path parameter name and its value in request path
type PathValue struct {
	Name  string
	Value string
}

// Get returns path parameter value for given name or false.
func (p PathValues) Get(name string) (string, bool) {
	for _, param := range p {
		if param.Name == name {
			return param.Value, true
		}
	}
	return "", false
}

// GetOr returns path parameter value for given name or default value if the name does not exist.
func (p PathValues) GetOr(name string, defaultValue string) string {
	for _, param := range p {
		if param.Name == name {
			return param.Value
		}
	}
	return defaultValue
}
