module github.com/labstack/echo/v5

go 1.25.0

require (
	github.com/stretchr/testify v1.11.1
	golang.org/x/net v0.57.0
	golang.org/x/time v0.15.0
)

require (
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	golang.org/x/text v0.40.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)
